import 'package:app_vigilance/model/form_open_house_sample_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../model/form_open_house_model.dart';
import '../service/form_open_house_service.dart';

class FormOpenHouseHelper {
  Future<bool?> formGetAllformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    FormOpenHouseService _service = FormOpenHouseService();
    final prefs = await SharedPreferences.getInstance();

    String? token = prefs.getString("token");
    if (token != null) {
      _service.getAllformOpenHouse(formOpenHouse, formOpenHouseSample, token);
    }
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("token", token);
      return true;
    } else {
      return null;
    }
  }

  Future<bool?> formGetformOpenHouseByID(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    FormOpenHouseService _service = FormOpenHouseService();
    final prefs = await SharedPreferences.getInstance();
    //Map<String, dynamic> responseJson = await jsonDecode(response.toString());
    String? token = prefs.getString("token");
    if (token != null) {
      _service.getAllformOpenHouse(formOpenHouse, formOpenHouseSample, token);
    }
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("token", token);
      return true;
    } else {
      return null;
    }
  }

  Future<bool?> formInsertAddformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    FormOpenHouseService _service = FormOpenHouseService();
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("token");
    if (token != null) {
      _service.getAllformOpenHouse(formOpenHouse, formOpenHouseSample, token);
    }
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("token", token);
      return true;
    } else {
      return null;
    }
  }

  Future<bool?> formInsertUpdateformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    FormOpenHouseService _service = FormOpenHouseService();
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("token");
    if (token != null) {
      _service.getAllformOpenHouse(formOpenHouse, formOpenHouseSample, token);
    }
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("token", token);
      return true;
    } else {
      return null;
    }
  }

  Future<bool?> formDeleteformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    FormOpenHouseService _service = FormOpenHouseService();
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString("token");
    if (token != null) {
      _service.getAllformOpenHouse(formOpenHouse, formOpenHouseSample, token);
    }
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("token", token);
      return true;
    } else {
      return null;
    }
  }
}
