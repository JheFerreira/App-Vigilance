import 'package:shared_preferences/shared_preferences.dart';
import '../model/form_closed_house_model.dart';
import '../service/form_closed_house_service.dart';

class FormClosedHouseHelper {
  Future<FormClosedHouse?> formGetAllformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    FormClosedHouseService _service = FormClosedHouseService();
    FormClosedHouse? token = await _service.getAllformClosedHouse(
        data, cep, endereco, complemento, bairro, cidade, estado, retorno);
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("retorno", token.retorno);
      return token;
    } else {
      return null;
    }
  }
  Future<FormClosedHouse?> formGetformClosedHouseByID(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    FormClosedHouseService _service = FormClosedHouseService();
    FormClosedHouse? token = await _service.getformClosedHouseByID(
        data, cep, endereco, complemento, bairro, cidade, estado, retorno);
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("retorno", token.retorno);
      return token;
    } else {
      return null;
    }
  }
  Future<FormClosedHouse?> formInsertAddformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    FormClosedHouseService _service = FormClosedHouseService();
    FormClosedHouse? token = await _service.insertAddformClosedHouse(
        data, cep, endereco, complemento, bairro, cidade, estado, retorno);
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("retorno", token.retorno);
      return token;
    } else {
      return null;
    }
  }
  Future<FormClosedHouse?> formInsertUpdateformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    FormClosedHouseService _service = FormClosedHouseService();
    FormClosedHouse? token = await _service.insertUpdateformClosedHouse(
        data, cep, endereco, complemento, bairro, cidade, estado, retorno);
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("retorno", token.retorno);
      return token;
    } else {
      return null;
    }
  }
  Future<FormClosedHouse?> formDeleteformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    FormClosedHouseService _service = FormClosedHouseService();
    FormClosedHouse? token = await _service.deleteformClosedHouse(
        data, cep, endereco, complemento, bairro, cidade, estado, retorno);
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool("cadastrado", true);
      prefs.setString("retorno", token.retorno);
      return token;
    } else {
      return null;
    }
  }
}
