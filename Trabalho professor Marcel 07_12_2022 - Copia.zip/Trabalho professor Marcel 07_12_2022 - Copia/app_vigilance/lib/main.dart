import 'package:app_vigilance/screens/form_closed_house_screen.dart';
import 'package:app_vigilance/screens/form_open_house_sample_screen.dart';
import 'package:app_vigilance/screens/list_closed_house_screen.dart';
import 'package:app_vigilance/screens/list_open_house_screen.dart';
import 'package:app_vigilance/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'bindings/main_binding.dart';
import 'screens/form_open_house_screen.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Demi Vigilance',
      debugShowCheckedModeBanner: false,
      initialRoute: "/home",
      getPages: [
        GetPage(name: "/login", page: () => const LoginScreen()),
        GetPage(
            name: "/home",
            page: () => const HomeScreen(),
            binding: MainBinding()),
        GetPage(
            name: "/formOpen",
            page: () => FormOpenHouseScreen(),
            binding: MainBinding()),
        GetPage(
            name: "/formClosed",
            page: () => FormClosedHouseScreen(),
            binding: MainBinding()),
        GetPage(
            name: "/formOpenSample",
            page: () => FormOpenHouseSampleScreen(),
            binding: MainBinding()),
        GetPage(
            name: "/listOpenHouse",
            page: () => ListOpenHouseScreen(),
            binding: MainBinding()),
        // GetPage(
        //     name: "/listClosedHouse",
        //     page: () => ListClosedHouseScreen(),
        //     binding: MainBinding()),
      ],
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textSelectionTheme:
            const TextSelectionThemeData(cursorColor: Colors.white),
      ).copyWith(
        primaryColor: Colors.grey,
      ),
    );
  }
}
