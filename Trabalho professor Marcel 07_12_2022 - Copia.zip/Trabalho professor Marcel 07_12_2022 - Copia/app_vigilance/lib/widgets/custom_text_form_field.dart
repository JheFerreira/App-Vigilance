import 'package:flutter/material.dart';

class CustomTextFormField extends StatefulWidget {
  Icon? prefixIcon;
  var suffixIcon;
  Icon? icon;
  Color? iconColor;
  Border? border;
  String hintText;
  var validator;
  bool obscureText = false;
  TextEditingController controller;

  CustomTextFormField({
    required this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.icon,
    this.iconColor,
    this.border,
    this.validator,
    this.obscureText = false,
    required this.controller,
  });

  @override
  State<CustomTextFormField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextFormField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      obscureText: widget.obscureText,
      validator: widget.validator,
      decoration: InputDecoration(
        prefixIcon: widget.prefixIcon,
        suffixIcon: widget.suffixIcon,
        icon: widget.icon,
        border: InputBorder.none,
        iconColor: Colors.grey,
        hintText: widget.hintText,
      ),
    );
  }
}
