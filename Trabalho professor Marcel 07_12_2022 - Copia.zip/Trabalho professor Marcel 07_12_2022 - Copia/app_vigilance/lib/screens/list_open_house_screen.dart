import 'package:flutter/material.dart';
import '../databases/file_persistence.dart';
import '../model/form_open_house_model.dart';
import '../widgets/custom_app_bar.dart';
import 'form_open_house_screen.dart';

class ListOpenHouseScreen extends StatefulWidget {
  const ListOpenHouseScreen({super.key});

  @override
  State<ListOpenHouseScreen> createState() => _ListOpenHouseScreenState();
}

class _ListOpenHouseScreenState extends State<ListOpenHouseScreen> {
  List<FormOpenHouse> _newFormOpenHouse = List.empty(growable: true);
  final FilePersistence _filePersistence = FilePersistence();

  @override
  void initState() {
    super.initState();
    _filePersistence.getData().then((listaFormularios) {
      setState(() {
        if (listaFormularios != null) {
          _newFormOpenHouse = listaFormularios;
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          // title: const Text('RubyTech'),
          // centerTitle: true,
          child: CustomAppBar(
            'Registros das Casas Abertas',
          ),
        ),
        body: Container(
          child: ListView.separated(
            itemCount: _newFormOpenHouse.length,
            separatorBuilder: (context, position) => Divider(),
            itemBuilder: (context, position) {
              FormOpenHouse _item = _newFormOpenHouse[position];
              return Dismissible(
                key: UniqueKey(),
                secondaryBackground: Container(
                  color: Colors.red,
                  child: const Align(
                      alignment: Alignment(0.9, 0.0),
                      child: Icon(
                        Icons.delete,
                        color: Colors.black,
                      )),
                ),
                background: Container(
                  color: Colors.yellow[800],
                  child: const Align(
                      alignment: Alignment(-0.9, 0.0),
                      child: Icon(
                        Icons.edit,
                        color: Colors.black,
                      )),
                ),
                onDismissed: (direction) {
                  if (direction == DismissDirection.endToStart) {
                    setState(() {
                      _newFormOpenHouse.removeAt(position);
                    });
                  }
                },
                confirmDismiss: (direction) async {
                  if (direction == DismissDirection.startToEnd) {
                    FormOpenHouse? editFormOpenHouse = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                FormOpenHouseScreen(formsOpenHouse: _item)));
                    if (editFormOpenHouse != null) {
                      setState(() {
                        _newFormOpenHouse.removeAt(position);
                        _newFormOpenHouse.insert(position, editFormOpenHouse);
                        _filePersistence.saveData(_newFormOpenHouse);

                        const SnackBar snackBar = SnackBar(
                          content: Text("Cadastro alterado com sucesso!"),
                          backgroundColor: Color.fromARGB(255, 221, 188, 0),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      });
                    }
                    return false;
                  } else {
                    return true;
                  }
                },
                child: ListTile(
                  title: Text(
                    _item.nomeCompleto,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    _item.cep,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () {
                    setState(() {
                      _item.done = !_item.done;
                    });
                  },
                  onLongPress: () async {
                    FormOpenHouse? editFormOpenHouse = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                FormOpenHouseScreen(formsOpenHouse: _item)));
                    if (editFormOpenHouse != null) {
                      setState(() {
                        _newFormOpenHouse.removeAt(position);
                        _newFormOpenHouse.insert(position, editFormOpenHouse);
                        _filePersistence.saveData(_newFormOpenHouse);

                        const SnackBar snackBar = SnackBar(
                          content: Text("Cadastro alterado com sucesso!"),
                          backgroundColor: Color.fromARGB(255, 221, 188, 0),
                        );

                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      });
                    }
                  },
                ),
              );
            },
          ),
        ));
  }
}
