import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../model/form_open_house_model.dart';
import '../widgets/custom_text_form_field.dart';

class FormOpenHouseScreen extends StatefulWidget {
  FormOpenHouse? formsOpenHouse;

  FormOpenHouseScreen({this.formsOpenHouse});

  @override
  State<FormOpenHouseScreen> createState() => _CadastroScreenState();
}

class _CadastroScreenState extends State<FormOpenHouseScreen> {
  List<FormOpenHouse> _newFormOpenHouse = List.empty(growable: true);
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController _nomeCompletoController = TextEditingController();
  TextEditingController _telefoneController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _cepController = TextEditingController();
  TextEditingController _logradouroController = TextEditingController();
  TextEditingController _complementoController = TextEditingController();
  TextEditingController _bairroController = TextEditingController();
  TextEditingController _cidadeController = TextEditingController();
  TextEditingController _estadoController = TextEditingController();

  @override
  void initState() {
    super.initState();

    if (widget.formsOpenHouse != null) {
      setState(() {
        _nomeCompletoController.text = widget.formsOpenHouse!.nomeCompleto;
        _telefoneController.text = widget.formsOpenHouse!.telefone;
        _emailController.text = widget.formsOpenHouse!.eMail;
        _cepController.text = widget.formsOpenHouse!.cep;
        _logradouroController.text = widget.formsOpenHouse!.logradouro;
        _complementoController.text = widget.formsOpenHouse!.complemento;
        _bairroController.text = widget.formsOpenHouse!.bairro;
        _cidadeController.text = widget.formsOpenHouse!.cidade;
        _estadoController.text = widget.formsOpenHouse!.estado;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // automaticallyImplyLeading: false,
        title: const Text("Cadastro do Cliente"),
        centerTitle: true,
        backgroundColor: Theme.of(context).primaryColor,
        flexibleSpace: Container(
            decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            colors: [
              Color.fromARGB(167, 59, 128, 63),
              Color.fromARGB(146, 41, 165, 10),
            ],
          ),
        )),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                _nomeCompletoController.text = "";
                _telefoneController.text = "";
                _emailController.text = "";
                _cepController.text = "";
                _logradouroController.text = "";
                _complementoController.text = "";
                _bairroController.text = "";
                _cidadeController.text = "";
                _estadoController.text = "";
              });
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _nomeCompletoController,
                    hintText: 'Nome Completo',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  //margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _telefoneController,
                    hintText: 'Telefone',
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _emailController,
                    hintText: 'Email',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  // margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _cepController,
                    hintText: 'CEP',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _logradouroController,
                    hintText: 'Logradouro',
                  ),
                ),
                Container(
                  // margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _complementoController,
                    hintText: 'Complemento',
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _bairroController,
                    hintText: 'Bairro',
                  ),
                ),
                Container(
                  //margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _cidadeController,
                    hintText: 'Cidade',
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _estadoController,
                    hintText: 'Estado',
                  ),
                ),
                Container(
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          margin: EdgeInsets.symmetric(vertical: 30),
                          height: 70,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.green[700]),
                              onPressed: () {
                                FocusScope.of(context).unfocus();
                                if (_formKey.currentState!.validate()) {
                                  FormOpenHouse formsOpenHouse = FormOpenHouse(
                                    nomeCompleto: _nomeCompletoController.text,
                                    telefone: _telefoneController.text,
                                    eMail: _emailController.text,
                                    cep: _cepController.text,
                                    logradouro: _logradouroController.text,
                                    complemento: _complementoController.text,
                                    bairro: _bairroController.text,
                                    cidade: _cidadeController.text,
                                    estado: _estadoController.text,
                                  );

                                  Get.toNamed('/formOpenSample', parameters: {
                                    'data': jsonEncode(formsOpenHouse)
                                  });
                                }
                              },
                              child: const Text(
                                "Próximo",
                                style: TextStyle(
                                    fontSize: 18, color: Colors.white),
                              )),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
