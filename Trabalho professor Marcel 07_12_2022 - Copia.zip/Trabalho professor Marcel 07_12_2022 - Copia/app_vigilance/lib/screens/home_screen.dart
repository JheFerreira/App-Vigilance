import 'package:app_vigilance/model/form_open_house_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../databases/file_persistence.dart';
import '../helper/post_login_helper.dart';
import '../model/form_closed_house_model.dart';
import '../model/post_login_model.dart';
import '../widgets/custom_curve_clipper.dart';
import 'form_closed_house_screen.dart';
import 'form_open_house_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  late Future<List<PostLogin>> _posts;
  final PostLoginHelper _helper = PostLoginHelper();
  List<FormOpenHouse> _newFormOpenHouse = List.empty(growable: true);
  List<FormClosedHouse> _newFormClosedHouse = List.empty(growable: true);
  final FilePersistence _filePersistence = FilePersistence();

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    if (await _helper.isUserLogged()) {}
  }

  @override
  Widget build(BuildContext context) {
    Size media = MediaQuery.of(context).size;
    print("Build Tela Home");
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: SingleChildScrollView(
          child: Container(
            height: media.height,
            width: double.infinity,
            child: Stack(
              children: [
                ClipPath(
                  clipper: CustomCurveClipper(),
                  child: Container(
                    width: media.width,
                    height: media.height * .30,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color.fromARGB(167, 59, 128, 63),
                          Color.fromARGB(146, 41, 165, 10),
                        ],
                      ),
                    ),
                    // child: InkWell(
                    //   onTap: () {
                    //     Get.toNamed('/login');
                    //   },
                    //   // highlightColor: Colors.green.withOpacity(0.5),
                    //   // borderRadius: BorderRadius.circular(10),
                    //   // radius: 10,
                    //   child: Container(
                    //     padding: const EdgeInsets.symmetric(
                    //         vertical: 12, horizontal: 24),
                    //     decoration: BoxDecoration(
                    //       borderRadius: BorderRadius.circular(5),
                    //     ),
                    //     child: Icon(
                    //       Icons.close,
                    //       size: 30,
                    //       color: Colors.white,
                    //     ),
                    //   ),
                    // ),
                  ),
                ),
                Positioned(
                  top: 50,
                  width: media.width,
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 30),
                    alignment: Alignment.center,
                    child: Text(
                      'Demi Vigilance',
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                ),
                Positioned(
                  top: media.height * .4,
                  width: media.width,
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 45,
                      vertical: 50,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () async {
                              try {
                                FormOpenHouse? formOpenHouse =
                                    await Navigator.push(
                                  context, // transição da tela home para a tela cadastro
                                  MaterialPageRoute(
                                    builder: (context) => FormOpenHouseScreen(),
                                  ),
                                );
                                if (formOpenHouse != null) {
                                  setState(() {
                                    _newFormOpenHouse.add(formOpenHouse);
                                    _filePersistence
                                        .saveData(_newFormOpenHouse);

                                    const SnackBar snackBar = SnackBar(
                                      content:
                                          Text("Cadastro gravado com sucesso!"),
                                      backgroundColor:
                                          Color.fromARGB(255, 10, 182, 39),
                                    );

                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  });
                                }
                              } catch (error) {
                                print("Error: ${error.toString()}");
                              }
                            },
                            child: Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 1),
                              height: 145,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(146, 1, 150, 250),
                                    offset: Offset(1, 3),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                              child: Column(children: [
                                buildDashboardRow1(),
                                Divider(
                                  color: Colors.grey,
                                  height: 1,
                                ),
                              ]),
                            ),
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: InkWell(
                            onTap: () async {
                              try {
                                FormClosedHouse? formClosedHouse =
                                    await Navigator.push(
                                  context, // transição da tela home para a tela cadastro
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        FormClosedHouseScreen(),
                                  ),
                                );
                                if (formClosedHouse != null) {
                                  setState(() {
                                    _newFormClosedHouse.add(formClosedHouse);
                                    _filePersistence
                                        .saveData(_newFormOpenHouse);

                                    const SnackBar snackBar = SnackBar(
                                      content:
                                          Text("Cadastro gravado com sucesso!"),
                                      backgroundColor:
                                          Color.fromARGB(255, 10, 182, 39),
                                    );

                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackBar);
                                  });
                                }
                              } catch (error) {
                                print("Error: ${error.toString()}");
                              }
                            },
                            child: Container(
                              height: 145,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(146, 1, 150, 250),
                                    offset: Offset(1, 3),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                              child: Column(children: [
                                buildDashboardRow2(),
                                Divider(
                                  color: Colors.grey,
                                  height: 1,
                                ),
                              ]),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                begin: Alignment.topCenter,
                colors: [
                  Color.fromARGB(167, 59, 128, 63),
                  Color.fromARGB(146, 41, 165, 10),
                ],
              )),
              accountName: Text("Yasmim Cunha"),
              accountEmail: Text("yasmim@gmail.com"),
              currentAccountPicture: CircleAvatar(
                backgroundColor:
                    Theme.of(context).platform == TargetPlatform.values
                        ? Colors.green
                        : Colors.white,
                child: Text(
                  "Y",
                  style: TextStyle(fontSize: 40.0),
                ),
              ),
            ),
            //const Divider(color: Colors.black54),
            ListTile(
              leading: Icon(Icons.search),
              title: Text('Pesquisar'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.home_outlined),
              title: Text('Home'),
              onTap: () {
                Get.to(HomeScreen());
              },
            ),
            ListTile(
              leading: Icon(Icons.list),
              title: Text('Lista'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Configurações'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.security),
              title: Text('Segurança'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.close),
              title: Text('Sair'),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

Widget buildDashboardRow1() {
  return Expanded(
    child: Row(
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              children: [
                Container(
                  // width: 50,
                  height: 80,
                  alignment: Alignment.center,
                  child: Icon(
                    Icons.home,
                    size: 50,
                    color: Colors.green,
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Aberta',
                        style: TextStyle(
                            color: Colors.green, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

Widget buildDashboardRow2() {
  return Expanded(
    child: Row(
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              children: [
                Container(
                  // width: 50,
                  height: 80,
                  alignment: Alignment.center,
                  child: Icon(
                    Icons.home,
                    size: 50,
                    color: Colors.green,
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Fechada',
                        style: TextStyle(
                            color: Colors.green, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
