import 'dart:convert';

import 'package:app_vigilance/model/form_open_house_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../model/form_open_house_sample_model.dart';
import '../widgets/custom_text_form_field.dart';

class FormOpenHouseSampleScreen extends StatefulWidget {
  FormOpenHouseSample? formsOpenHouse;

  FormOpenHouseSampleScreen({this.formsOpenHouse});

  @override
  State<FormOpenHouseSampleScreen> createState() => _CadastroScreenState();
}

class _CadastroScreenState extends State<FormOpenHouseSampleScreen> {
  List<FormOpenHouseSample> _newFormOpenHouse = List.empty(growable: true);
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController _larvaController = TextEditingController();
  TextEditingController _pupaController = TextEditingController();
  TextEditingController _quantidadeLarvaController = TextEditingController();
  TextEditingController _codigoDepositoController = TextEditingController();
  TextEditingController _depositoController = TextEditingController();
  TextEditingController _especieController = TextEditingController();
  late FormOpenHouse formsOpenHouse;

  @override
  void initState() {
    super.initState();

    formsOpenHouse = jsonDecode(Get.parameters['data']!);

    if (widget.formsOpenHouse != null) {
      setState(() {
        _larvaController.text = widget.formsOpenHouse!.larva;
        _pupaController.text = widget.formsOpenHouse!.pupa;
        _quantidadeLarvaController.text =
            widget.formsOpenHouse!.quantidadeLarva;
        _codigoDepositoController.text = widget.formsOpenHouse!.larva;
        _depositoController.text = widget.formsOpenHouse!.deposito;
        _especieController.text = widget.formsOpenHouse!.especie;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Cadastro da Amostra"),
        centerTitle: true,
        backgroundColor: Theme.of(context).primaryColor,
        flexibleSpace: Container(
            decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            colors: [
              Color.fromARGB(167, 59, 128, 63),
              Color.fromARGB(146, 41, 165, 10),
            ],
          ),
        )),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                _larvaController.text = "";
                _pupaController.text = "";
                _quantidadeLarvaController.text = "";
                _codigoDepositoController.text = "";
                _depositoController.text = "";
                _especieController.text = "";
              });
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _larvaController,
                    hintText: 'Larva',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  //margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _pupaController,
                    hintText: 'Pupa',
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _quantidadeLarvaController,
                    hintText: 'Quantidade de Larva',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  //margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _codigoDepositoController,
                    hintText: 'Código do Depósito',
                    validator: (value) {
                      if (value!.isEmpty) return 'Preenchimento Obrigatório!';
                    },
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _depositoController,
                    hintText: 'Depósito',
                  ),
                ),
                Container(
                  //margin: EdgeInsets.symmetric(vertical: 40),
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  padding:
                      EdgeInsets.only(top: 4, left: 16, right: 16, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(2),
                    ),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: CustomTextFormField(
                    controller: _especieController,
                    hintText: 'Espécie',
                  ),
                ),
                Container(
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          //margin: EdgeInsets.symmetric(vertical: 30),
                          height: 70,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: widget.formsOpenHouse == null
                                    ? Colors.green[700]
                                    : Colors.yellow[700]),
                            onPressed: () {
                              FocusScope.of(context).unfocus();
                              if (_formKey.currentState!.validate()) {
                                FormOpenHouseSample formsOpenHouse =
                                    FormOpenHouseSample(
                                  larva: _larvaController.text,
                                  pupa: _pupaController.text,
                                  quantidadeLarva:
                                      _quantidadeLarvaController.text,
                                  codigoDeposito:
                                      _codigoDepositoController.text,
                                  deposito: _depositoController.text,
                                  especie: _especieController.text,
                                );

                                Get.toNamed('/listOpenHouse');
                              }
                            },
                            child: widget.formsOpenHouse == null
                                ? const Text(
                                    "Cadastrar",
                                    style: TextStyle(
                                        fontSize: 18, color: Colors.white),
                                  )
                                : const Text(
                                    "Editar",
                                    style: TextStyle(
                                        fontSize: 18, color: Colors.white),
                                  ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          margin: EdgeInsets.symmetric(vertical: 30),
                          height: 70,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.red[900],
                            ),
                            child: const Text(
                              "Cancelar",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                              ),
                            ),
                            onPressed: () {
                              Get.toNamed('/home');
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
