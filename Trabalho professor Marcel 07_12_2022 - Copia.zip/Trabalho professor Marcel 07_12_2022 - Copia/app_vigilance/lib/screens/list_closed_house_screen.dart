import 'package:flutter/material.dart';
import '../databases/file_persistence.dart';
import '../model/form_closed_house_model.dart';
import '../widgets/custom_app_bar.dart';
import 'form_closed_house_screen.dart';

class ListClosedHouseScreen extends StatefulWidget {
  const ListClosedHouseScreen({super.key});

  @override
  State<ListClosedHouseScreen> createState() => _ListClosedHouseScreenState();
}

class _ListClosedHouseScreenState extends State<ListClosedHouseScreen> {
  List<FormClosedHouse> _newFormClosedHouse = List.empty(growable: true);
  final FilePersistence _filePersistence = FilePersistence();

  @override
  void initState() {
    super.initState();
    _filePersistence.getData().then((listaFormularios) {
      setState(() {
        if (listaFormularios != null) {
         // _newFormClosedHouse = listaFormularios;
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          // title: const Text('RubyTech'),
          // centerTitle: true,
          child: CustomAppBar(
            'Registros das Casas Abertas',
          ),
        ),
        body: Container(
          child: ListView.separated(
            itemCount: _newFormClosedHouse.length,
            separatorBuilder: (context, position) => Divider(),
            itemBuilder: (context, position) {
              FormClosedHouse _item = _newFormClosedHouse[position];
              return Dismissible(
                key: UniqueKey(),
                secondaryBackground: Container(
                  color: Colors.red,
                  child: const Align(
                      alignment: Alignment(0.9, 0.0),
                      child: Icon(
                        Icons.delete,
                        color: Colors.black,
                      )),
                ),
                background: Container(
                  color: Colors.yellow[800],
                  child: const Align(
                      alignment: Alignment(-0.9, 0.0),
                      child: Icon(
                        Icons.edit,
                        color: Colors.black,
                      )),
                ),
                onDismissed: (direction) {
                  if (direction == DismissDirection.endToStart) {
                    setState(() {
                      _newFormClosedHouse.removeAt(position);
                    });
                  }
                },
                confirmDismiss: (direction) async {
                  if (direction == DismissDirection.startToEnd) {
                    FormClosedHouse? editFormClosedHouse = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                FormClosedHouseScreen(formsClosedHouse: _item)));
                    if (editFormClosedHouse != null) {
                      setState(() {
                        _newFormClosedHouse.removeAt(position);
                        _newFormClosedHouse.insert(position, editFormClosedHouse);
                       // _filePersistence.saveData(_newFormClosedHouse);

                        const SnackBar snackBar = SnackBar(
                          content: Text("Cadastro alterado com sucesso!"),
                          backgroundColor: Color.fromARGB(255, 221, 188, 0),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      });
                    }
                    return false;
                  } else {
                    return true;
                  }
                },
                child: ListTile(
                  title: Text(
                    _item.data,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    _item.cep,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () {
                    setState(() {
                      _item.done = !_item.done;
                    });
                  },
                  onLongPress: () async {
                    FormClosedHouse? editFormClosedHouse = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                FormClosedHouseScreen(formsClosedHouse: _item)));
                    if (editFormClosedHouse != null) {
                      setState(() {
                        _newFormClosedHouse.removeAt(position);
                        _newFormClosedHouse.insert(position, editFormClosedHouse);
                       // _filePersistence.saveData(_newFormClosedHouse);

                        const SnackBar snackBar = SnackBar(
                          content: Text("Cadastro alterado com sucesso!"),
                          backgroundColor: Color.fromARGB(255, 221, 188, 0),
                        );

                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      });
                    }
                  },
                ),
              );
            },
          ),
        ));
  }
}
