import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';
import '../model/form_closed_house_model.dart';

class FormClosedHouseService {
  Future<FormClosedHouse?> getAllformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/formClosedHouse/getAllformClosedHouse');
    http.post(url, body: {
      "data": data,
      "cep": cep,
      "endereco": endereco,
      "complemento": complemento,
      "bairro": bairro,
      "cidade": cidade,
      "estado": estado,
      "retorno": retorno
    }).then((response) {
      print("Chamando url de cadastrar formulario");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }
  Future<FormClosedHouse?> getformClosedHouseByID(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/formClosedHouse/getformClosedHouseByID/:id');
    http.post(url, body: {
      "data": data,
      "cep": cep,
      "endereco": endereco,
      "complemento": complemento,
      "bairro": bairro,
      "cidade": cidade,
      "estado": estado,
      "retorno": retorno
    }).then((response) {
      print("Chamando url de cadastrar formulario");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }
  Future<FormClosedHouse?> insertAddformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/formClosedHouse/addformClosedHouse');
    http.post(url, body: {
      "data": data,
      "cep": cep,
      "endereco": endereco,
      "complemento": complemento,
      "bairro": bairro,
      "cidade": cidade,
      "estado": estado,
      "retorno": retorno
    }).then((response) {
      print("Chamando url de cadastrar formulario");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }
  Future<FormClosedHouse?> insertUpdateformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/formClosedHouse/updateformClosedHouse/:id');
    http.post(url, body: {
      "data": data,
      "cep": cep,
      "endereco": endereco,
      "complemento": complemento,
      "bairro": bairro,
      "cidade": cidade,
      "estado": estado,
      "retorno": retorno
    }).then((response) {
      print("Chamando url de cadastrar formulario");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }
  Future<FormClosedHouse?> deleteformClosedHouse(
      String data,
      String cep,
      String endereco,
      String complemento,
      String bairro,
      String cidade,
      String estado,
      String retorno) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/formClosedHouse/deleteformClosedHouse/:id');
    http.post(url, body: {
      "data": data,
      "cep": cep,
      "endereco": endereco,
      "complemento": complemento,
      "bairro": bairro,
      "cidade": cidade,
      "estado": estado,
      "retorno": retorno
    }).then((response) {
      print("Chamando url de cadastrar formulario");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }
}
