import 'dart:convert';
import 'package:app_vigilance/screens/login_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import '../model/post_login_model.dart';

class LoginService {
  Future<List<PostLogin>> fetchPosts({int? userId}) async {
    final url = userId != null
        ? await 'http:/192.168.56.1:3000/login/posts?userId=$userId'
        : await 'http:/192.168.56.1:3000/login/posts';
    final response = await http.get(Uri.parse(url));
    List<PostLogin> posts = List<PostLogin>.empty(growable: true);

    if (response.statusCode == 200) {
      List resList = jsonDecode(response.body)['token'];

      resList.forEach((mPost) {
        posts.add(PostLogin.fromJson(mPost));
      });
    }
    return posts;
  }

  Future<PostLogin?> insertSignup(String username, String cpf, String telefone,
      String email, String password) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/signup');
    http.post(url, body: {
      "username": username,
      "cpf": cpf,
      "telefone": "telefone",
      "email": email,
      "password": password
    }).then((response) {
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }

  Future<PostLogin?> getAllUsers(String nome, String cpf, String telefone,
      String email, String senha) async {
    Uri url = Uri.parse('http:/192.168.56.1/login/getAllUsers');
    http.post(url, body: {
      "nome": nome,
      "cpf": cpf,
      "telefone": telefone,
      "email": email,
      "senha": senha
    }).then((response) {
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }

  Future<PostLogin?> getUserByID(String nome, String cpf, String telefone,
      String email, String senha) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/getUserByID/:id');
    http.post(url, body: {
      "nome": nome,
      "cpf": cpf,
      "telefone": telefone,
      "email": email,
      "senha": senha
    }).then((response) {
      print("Chamando url de cadastrar usuário");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }

  Future<PostLogin?> insertUpdateUser(String nome, String cpf, String telefone,
      String email, String senha) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/updateUser/:id');
    http.post(url, body: {
      "nome": nome,
      "cpf": cpf,
      "telefone": telefone,
      "email": email,
      "senha": senha
    }).then((response) {
      print("Chamando url de cadastrar usuário");
      print(response);
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }

  Future<PostLogin?> getDeleteUser(String nome, String cpf, String telefone,
      String email, String senha) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/deleteUser/:id');
    http.post(url, body: {
      "nome": nome,
      "cpf": cpf,
      "telefone": telefone,
      "email": email,
      "senha": senha
    }).then((response) {
      if (response.statusCode == 200) {
        return jsonDecode(response.body)['token'];
      } else {
        Exception("Falha na conexão com o servidor!");
      }
    });
  }

  Future<String?> insertLogin(String username, String password) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/login');
    var response = await http
        .post(url, body: {"username": username, "password": password});
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['token'];
    } else {
      Exception("Falha na conexão com o servidor!");
      print(response.body);
    }
  }

  Future<bool> insertLogout(String token) async {
    Uri url = Uri.parse('http:/192.168.56.1:3000/login/logout');
    Map<String, String> requestHeaders = {
      'Authorization': 'Bearer ' + token
    };
    var response = await http.post(url, body: {}, headers: requestHeaders);
    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }
}


// class LoginService {
//   Future<PostLogin?> newLogin(PostLogin post) async {
//     String url = 'http://192.168.56.1:3000/login/signup';
//     final response = await http.post(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 201) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

//   Future<List<PostLogin>> fetchLogins({int? userId}) async {
//     final url = userId != null
//         ? await 'http://192.168.56.1:3000/login/posts?userId=$userId'
//         : await 'http://192.168.56.1:3000/login/posts';
//     final response = await http.get(Uri.parse(url));
//     List<PostLogin> posts = List<PostLogin>.empty(growable: true);

//     if (response.statusCode == 200) {
//       List resList = jsonDecode(response.body);

//       resList.forEach((mPost) {
//         posts.add(PostLogin.fromJson(mPost));
//       });
//     }
//     return posts;
//   }

//   Future<PostLogin?> getAllUsers(PostLogin post) async {
//     String url = 'http://192.168.56.1:3000/login/getAllUsers';
//     final response = await http.post(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 201) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

//   Future<PostLogin?> getUserByID(PostLogin post) async {
//     String url = 'http:/192.168.56.1:3000/login/getUserByID/:id';
//     final response = await http.post(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 201) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

//   Future<PostLogin?> editLogin(PostLogin post) async {
//     String url = await 'http:/192.168.56.1:3000/login/updateUser/:id';
//     final response = await http.put(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 200) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

//   Future<PostLogin?> removeLogin(int id) async {
//     String url = await 'http:/192.168.56.1:3000/login/deleteUser/:id';
//     final response =
//         await http.delete(Uri.parse(url), headers: <String, String>{
//       'Content-Type': 'application/json; charset=UTF-8',
//     });
//     if (response.statusCode == 200) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

// Future<PostLogin?> insertLogin(PostLogin post) async {
//     String url = 'http://192.168.56.1:3000/login/login';
//     final response = await http.post(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 201) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }

//   Future<PostLogin?> insertLogout(PostLogin post) async {
//     String url = 'http://192.168.56.1:3000/login/logout';
//     final response = await http.post(
//       Uri.parse(url),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',
//       },
//       body: json.encode(post.toJson()),
//     );
//     if (response.statusCode == 201) {
//       PostLogin rPost = PostLogin.fromJson(jsonDecode(response.body));
//       return rPost;
//     } else {
//       Exception("Falha na conexão com o servidor!");
//     }
//   }
// }
