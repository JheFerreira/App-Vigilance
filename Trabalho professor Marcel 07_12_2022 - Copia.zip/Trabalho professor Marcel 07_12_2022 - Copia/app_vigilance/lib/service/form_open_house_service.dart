import 'dart:convert';
import 'package:app_vigilance/model/form_open_house_sample_model.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import '../model/form_open_house_model.dart';

class FormOpenHouseService {
  Future<bool> getAllformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    Map<String, String> requestHeaders = {'Authorization': 'Bearer ' + token};
    Uri url =
        Uri.parse('http:/192.168.56.1:3000/formOpenHouse/getAllformOpenHouse');
    var response = await http.post(url,
        body: {
          "nomeCompleto": formOpenHouse.nomeCompleto,
          "telefone": formOpenHouse.telefone,
          "email": formOpenHouse.eMail,
          "cep": formOpenHouse.cep,
          "endereco": formOpenHouse.logradouro,
          "complemento": formOpenHouse.complemento,
          "bairro": formOpenHouse.bairro,
          "cidade": formOpenHouse.cidade,
          "estado": formOpenHouse.estado,
          "larva": formOpenHouseSample.larva,
          "pupa": formOpenHouseSample.pupa,
          "quantidadeLarva": formOpenHouseSample.quantidadeLarva,
          "codigoDeposito": formOpenHouseSample.codigoDeposito,
          "deposito": formOpenHouseSample.deposito,
          "especie": formOpenHouseSample.especie
        },
        headers: requestHeaders);

    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }

  Future<bool> getformOpenHouseByID(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    Map<String, String> requestHeaders = {'Authorization': 'Bearer ' + token};
    Uri url =
        Uri.parse('http:/192.168.56.1:3000/formOpenHouse/getAllformOpenHouse');
    var response = await http.post(url,
        body: {
          "nomeCompleto": formOpenHouse.nomeCompleto,
          "telefone": formOpenHouse.telefone,
          "email": formOpenHouse.eMail,
          "cep": formOpenHouse.cep,
          "endereco": formOpenHouse.logradouro,
          "complemento": formOpenHouse.complemento,
          "bairro": formOpenHouse.bairro,
          "cidade": formOpenHouse.cidade,
          "estado": formOpenHouse.estado,
          "larva": formOpenHouseSample.larva,
          "pupa": formOpenHouseSample.pupa,
          "quantidadeLarva": formOpenHouseSample.quantidadeLarva,
          "codigoDeposito": formOpenHouseSample.codigoDeposito,
          "deposito": formOpenHouseSample.deposito,
          "especie": formOpenHouseSample.especie
        },
        headers: requestHeaders);

    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }

  Future<bool> insertAddformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    Map<String, String> requestHeaders = {'Authorization': 'Bearer ' + token};
    Uri url =
        Uri.parse('http:/192.168.56.1:3000/formOpenHouse/getAllformOpenHouse');
    var response = await http.post(url,
        body: {
          "nomeCompleto": formOpenHouse.nomeCompleto,
          "telefone": formOpenHouse.telefone,
          "email": formOpenHouse.eMail,
          "cep": formOpenHouse.cep,
          "endereco": formOpenHouse.logradouro,
          "complemento": formOpenHouse.complemento,
          "bairro": formOpenHouse.bairro,
          "cidade": formOpenHouse.cidade,
          "estado": formOpenHouse.estado,
          "larva": formOpenHouseSample.larva,
          "pupa": formOpenHouseSample.pupa,
          "quantidadeLarva": formOpenHouseSample.quantidadeLarva,
          "codigoDeposito": formOpenHouseSample.codigoDeposito,
          "deposito": formOpenHouseSample.deposito,
          "especie": formOpenHouseSample.especie
        },
        headers: requestHeaders);

    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }

  Future<bool> insertUpdateformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    Map<String, String> requestHeaders = {'Authorization': 'Bearer ' + token};
    Uri url =
        Uri.parse('http:/192.168.56.1:3000/formOpenHouse/getAllformOpenHouse');
    var response = await http.put(url,
        body: {
          "nomeCompleto": formOpenHouse.nomeCompleto,
          "telefone": formOpenHouse.telefone,
          "email": formOpenHouse.eMail,
          "cep": formOpenHouse.cep,
          "endereco": formOpenHouse.logradouro,
          "complemento": formOpenHouse.complemento,
          "bairro": formOpenHouse.bairro,
          "cidade": formOpenHouse.cidade,
          "estado": formOpenHouse.estado,
          "larva": formOpenHouseSample.larva,
          "pupa": formOpenHouseSample.pupa,
          "quantidadeLarva": formOpenHouseSample.quantidadeLarva,
          "codigoDeposito": formOpenHouseSample.codigoDeposito,
          "deposito": formOpenHouseSample.deposito,
          "especie": formOpenHouseSample.especie
        },
        headers: requestHeaders);

    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }

  Future<bool> deleteformOpenHouse(FormOpenHouse formOpenHouse,
      FormOpenHouseSample formOpenHouseSample, String token) async {
    Map<String, String> requestHeaders = {'Authorization': 'Bearer ' + token};
    Uri url =
        Uri.parse('http:/192.168.56.1:3000/formOpenHouse/getAllformOpenHouse');
    var response = await http.delete(url,
        body: {
          "nomeCompleto": formOpenHouse.nomeCompleto,
          "telefone": formOpenHouse.telefone,
          "email": formOpenHouse.eMail,
          "cep": formOpenHouse.cep,
          "endereco": formOpenHouse.logradouro,
          "complemento": formOpenHouse.complemento,
          "bairro": formOpenHouse.bairro,
          "cidade": formOpenHouse.cidade,
          "estado": formOpenHouse.estado,
          "larva": formOpenHouseSample.larva,
          "pupa": formOpenHouseSample.pupa,
          "quantidadeLarva": formOpenHouseSample.quantidadeLarva,
          "codigoDeposito": formOpenHouseSample.codigoDeposito,
          "deposito": formOpenHouseSample.deposito,
          "especie": formOpenHouseSample.especie
        },
        headers: requestHeaders);

    if (response.statusCode == 200) {
      return true;
    } else {
      Exception("Falha na conexão com o servidor!");
      return false;
    }
  }
}