import 'dart:convert';

FormOpenHouse FormOpenHouseFromJson(String str) =>
    FormOpenHouse.fromJson(json.decode(str));

String FormOpenHouseToJson(FormOpenHouse data) =>
    json.encode(data.toJson());

class FormOpenHouse {
  FormOpenHouse({
    required this.nomeCompleto,
    required this.telefone,
    required this.eMail,
    required this.cep,
    required this.logradouro,
    required this.complemento,
    required this.bairro,
    required this.cidade,
    required this.estado,
  });

  String nomeCompleto;
  String telefone;
  String eMail;
  String cep;
  String logradouro;
  String complemento;
  String bairro;
  String cidade;
  String estado;
  bool done = false;

  factory FormOpenHouse.fromJson(Map<String, dynamic> json) =>
      FormOpenHouse(
        nomeCompleto: json["nomeCompleto"],
        telefone: json["telefone"],
        eMail: json["e-mail"],
        cep: json["cep"],
        logradouro: json["logradouro"],
        complemento: json["complemento"],
        bairro: json["bairro"],
        cidade: json["cidade"],
        estado: json["estado"],
      );

  Map<String, dynamic> toJson() => {
        "nomeCompleto": nomeCompleto,
        "telefone": telefone,
        "e-mail": eMail,
        "cep": cep,
        "logradouro": logradouro,
        "complemento": complemento,
        "bairro": bairro,
        "cidade": cidade,
        "estado": estado,
      };
}
