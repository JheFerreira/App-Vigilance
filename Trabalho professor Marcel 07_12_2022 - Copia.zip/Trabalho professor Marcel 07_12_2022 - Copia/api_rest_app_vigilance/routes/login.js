let express = require('express');
let router = express.Router();
let controller = require('../controllers/login');
let auth = require('../lib/auth');


router.post('/signup', controller.signup);
router.post('/login', controller.login);
router.post('/logout', auth.jwtVerify, controller.logout);
router.get('/getAllUsers', controller.getAllUsers);
router.get('/getUserByID/:id', controller.getUserByID);
router.put('/updateUser/:id', controller.updateUser);
router.delete('/deleteUser/:id', controller.deleteUser);


module.exports = router;