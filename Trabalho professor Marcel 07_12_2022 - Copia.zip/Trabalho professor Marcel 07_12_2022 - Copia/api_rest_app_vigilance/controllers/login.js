
const login = require('../models/login');

module.exports ={
//criar novo usuário
    signup: (req, res, next)=>{
    const{username, cpf, telefone, email, password} = req.body;
    const user = new login ({username, cpf, telefone, email, password});

    user.save()
    .then(userSaved =>{
        return res.status(201).json(userSaved);
    })
    .catch(error =>{
        return res.status(500).json(error.message);
    }) }, 

// //Buscar todos elementos (Usuarios)
    getAllUsers : (req, res, next) =>{
        login.find()
        .then(users => {
            return res.status(200).json(users);
            })   
        .catch(error =>{
            return res.status(500).json({msg: "Erro ao buscar usuários!", error: error.message})  
            });
    },

   getUserByID: async (req, res, next)=>{
        let idlogin = req.params.id;
        try{
                let usuario = await login.findById(idlogin) 
            if(usuario != null)
                return res.status(200).json(usuario)
            else
            return res.status(500).json({msg: "Erro ao buscar usuário!", error: "Usuário não existe!"})
        } catch(error){
            return res.status(500).json({msg: "Erro ao buscar usuário!", error: error.message})
        }
    },


    // addUser : async (req, res, next) =>{
    //     let newUser = new user();
    //     newUser.username =  req.body.username;
    //     newUser.cpf = req.body.cpf;
    //     newUser.email = req.body.email;
    //     newUser.password = req.body.password;
    //     newUser.telefone = req.body.telefone ? req.body.telefone: '';
    
    //    try{
    //         let savedUser = await newUser.save();
    //         return res.status(201).json({msg: "Usuário adicionado com sucesso !" , user: savedUser})
    //     }catch (error){
    //         return res.status (500).json({msg: "Erro ao salvar usuário" , error: error.message})
    //     }
    // },

   updateUser: async (req, res, next)=>{
        let idlogin = req.params.id;

        let loginUpdate = {} ;
        if(req.body.nome) loginUpdate.nome = req.body.nome;
        if(req.body.cpf) loginUpdate.cpf = req.body.cpf;
        if(req.body.telefone) loginUpdate.telefone = req.body.telefone;
        if(req.body.email) loginUpdate.email = req.body.email;
        if(req.body.senha) loginUpdate.senha = req.body.senha;

       try{
            await login.updateOne ({_id: idlogin}, loginUpdate)

            return res.status(200).json({msg: "Usuário atualizado com sucesso"});

       }catch(error){
        res.status(500).json({msg: "Erro ao atualizar usuário ! ", error: error.message}) 

       }
       
    }, 


    deleteUser: (req, res, next)=>{
        let idlogin = req.params.id;
        
        login.findByIdAndDelete(idlogin)
        .then(loginDeleted =>{
            res.status(200).json({msg: "Usuário removido com sucesso" , login: loginDeleted});
        })
        .catch(error =>{
            res.status(500).json({msg: "Erro ao remover usuário ! ", error: error.message})   

        })
    },

login: async (req, res, next)=>{
 const{username, password}= req.body;

    let user = await login.findOne({'username': username});
    if(user != null){
        user.comparePassword(password, (err, isMatch) =>{
            if(isMatch && !err){
        user.generateAuthToken()
        .then(sucesso =>{
            return res.status(200).json(sucesso);
        })
        .catch(error =>{
            //Erro 500 trata-se de erros internos, conexao com o banco, erro do servidor ou biblioteca, etc.
            return res.status(500).json(error);
        })
            }else{
                return  res.status(401).json({success: false, token: null, msg: "Senha incorreta!" }); 
                } 
        });
    }else{
        //Erro 401 falha referente a autenticação
        return res.status(401).json({success: false, token: null, msg: "Usuário não encontrado!" });
    }
},
logout: (req, res, next)=>{
        
    const userId = req.user._id;

   login.updateOne(
        {_id: userId},
        {
            $set: {
                token: null
            }
        }
    )
    .then(user =>{
        return res.status(200).json({
            success: true, 
            token: null,
            msg: "Logout realizado com sucesso!"
        })
    })
    .catch (error =>{
        return res.status(500).json({
            success: false,
            token: null, 
            msg: "Erro ao realizar logout. Tente novamente!"
        })
    })
}
};
    
