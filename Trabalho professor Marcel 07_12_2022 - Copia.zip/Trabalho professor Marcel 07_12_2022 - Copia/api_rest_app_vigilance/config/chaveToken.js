module.exports = {
    segredoToken: "SuperSegredoDeSenhaSecreta"
}